/*
 * Clock.cpp
 *
 *  Created on: Mar 4, 2020
 *      Author: jbbui
 */

#include "Clock.h"
#include "time.h"

#include <string>
#include <ctime>
#include <iostream>
#include <iomanip>
#include <Windows.h>
using namespace std;

Clock::Clock() {//initializes variables and starts the clock
   hourAdjust = 0;
   minAdjust = 0;
   secAdjust = 0;
   inputCommand = 0;
   runClock();


}

Clock::~Clock() {
}

void Clock::setClock(){
   //getting current time
   timeRaw = time(&timeRaw);
   timeLocal = localtime (&timeRaw);

   //setting hour for 24 hour clock
   hourRaw = (timeLocal->tm_hour + hourAdjust) % 24;
   hours24 = to_string(hourRaw);

   //setting hour for 12 hour clock and AM/PM
   if(hours24 > "12"){
      hours = hourRaw < 10 || (hourRaw > 12 && hourRaw < 22)  ? ("0" + (to_string(hourRaw-12))) : to_string(hourRaw-12);
	  amPm = "PM";
	}
	else{
	   hours = timeLocal->tm_hour < 10 ? ("0" + hours24) : hours24;
	   amPm = "AM";
	}

   //sets minutes
   minRaw = (timeLocal->tm_min + minAdjust) % 60;
   minutes = (minRaw < 10) ? ("0" + to_string(minRaw)) : to_string(minRaw);

   //sets seconds
   secRaw = (timeLocal->tm_sec + secAdjust) % 60;
   seconds = (secRaw < 10) ? ("0" + to_string(secRaw)) : to_string(secRaw) ;



}

void Clock::printClock(){//prints the clock to the command line
		cout << "***************************      "
				<< "***************************" << endl;
		cout << "*     12 - Hour Clock     *      "
				<< "*     24 - Hour Clock     *" << endl;
		cout << "*       " << hours << ":" << minutes << ":" << seconds << " " << amPm << "       *"
				<< "      *         " << hours24 << ":" << minutes << ":"  << seconds  << "        *" << endl;
		cout << "***************************      "
				<< "***************************" << endl;
		cout << "Press space for menu" << endl;
		return;
	}


void Clock::displayMenuScreen(){//prints the menu screen to the command line
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl;
}

void Clock::menuOps(){//handles the menu operations
	displayMenuScreen();//displaying the menu screen
	cin >> inputCommand;//getting the menu command
	switch(inputCommand){//handling the input command
	   case(1)://adjusts hours
		  hourAdjust++;
	      if(hourAdjust > 23){//roll over protection for hours
	   	     hourAdjust = 0;
	   	  }
	      break;
	   case(2)://adjusts minutes
		  minAdjust++;
	      if(minAdjust > 59){//roll over protection for minutes
	    	  minAdjust = 0;
	    	  hourAdjust++;
	    	  if(hourAdjust > 23){
	    	     hourAdjust = 0;
	    	  }
	      }
	      break;
	   case(3)://adjusts seconds
		  secAdjust++;
	      if(secAdjust > 59){//roll over protection for seconds
	   	      secAdjust = 0;
	   	   	  minAdjust++;
	   	      if(minAdjust > 59){
	   	   	     minAdjust = 0;
	   	    	 hourAdjust++;
	   	      }
	      }
	      break;
	   case(4):
		  throw inputCommand;//throws up the chain to end program
	      break;
	   default:
	      break;
	}
}

void Clock::runClock(){

	while(inputCommand != 4){//keeps the clocks running
	   this->setClock();//sets the current time values
	   this->printClock();//displays the current time
	   cout << string(20,'\n');//"clears" the screen
	   try{//listener for space key press
	      if(GetKeyState(VK_SPACE) & 0x8000){
		     menuOps();//brings up the menu when space is pressed
	      }
	   }
	   catch(int x){//catches the thrown quit command to end the program
		   break;
	   }
	}


}

