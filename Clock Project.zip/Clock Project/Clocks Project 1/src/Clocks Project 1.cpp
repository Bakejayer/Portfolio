#include "Clock.h"


#include <iostream>
using namespace std;

int main() {
	Clock  chadaTechClock;
	return 0;
}
