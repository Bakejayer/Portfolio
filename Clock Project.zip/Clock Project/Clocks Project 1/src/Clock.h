/*
 * Clock.h
 *
 *  Created on: Mar 4, 2020
 *      Author: jbbui
 */

#ifndef CLOCK_H_
#define CLOCK_H_

#include <string>
#include <ctime>
using namespace std;

class Clock {
public:
	Clock();
	virtual ~Clock();
	void printClock();
	void displayMenuScreen();
	void runClock();


private:
	time_t timeRaw;
	string amPm, hours, hours24, seconds, minutes;
	struct tm *timeLocal;
	int secAdjust, minAdjust, hourAdjust, minRaw, secRaw, hourRaw, inputCommand;
	void setClock();
	void menuOps();
};

#endif /* CLOCK_H_ */
